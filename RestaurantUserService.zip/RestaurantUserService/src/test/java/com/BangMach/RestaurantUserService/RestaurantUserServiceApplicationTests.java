package com.BangMach.RestaurantUserService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
